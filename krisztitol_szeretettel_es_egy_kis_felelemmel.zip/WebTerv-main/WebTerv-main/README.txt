-WebTervezés gyakorlat projekt-
GitHub repo: https://github.com/AbThy/WebTerv

Mivel a lebegodoboz nem eltuntetheto csak javascripttel ki lett kommentelve!